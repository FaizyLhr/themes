const { Tool } = require('./tool.entity')

/** @type {import('adminjs').ResourceOptions} */
const options = {

}

module.exports = {
  options,
  resource: Tool,
}
