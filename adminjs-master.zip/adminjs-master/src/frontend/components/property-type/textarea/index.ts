import Show from './show'
import Edit from './edit'

export {
  Show as show,
  Edit as edit,
}
