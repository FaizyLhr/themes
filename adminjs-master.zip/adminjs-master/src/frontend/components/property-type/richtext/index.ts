import Edit from './edit'
import Show from './show'
import List from './list'

export {
  Edit as edit,
  Show as show,
  List as list,
}
