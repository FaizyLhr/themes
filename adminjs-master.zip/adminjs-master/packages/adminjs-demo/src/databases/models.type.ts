export type AvailableModels = 'User' | 'BlogPost' | 'Brand' | 'Product' | 'Media'
