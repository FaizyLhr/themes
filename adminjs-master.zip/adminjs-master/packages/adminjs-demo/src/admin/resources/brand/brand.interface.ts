export interface BrandInterface {
  id: string;
  name: string;
}
