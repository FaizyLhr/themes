export * from './property-json.interface'
