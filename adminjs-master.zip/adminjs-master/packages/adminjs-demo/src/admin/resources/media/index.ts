export {
  MediaResource as options,
  MediaFeatures as features,
} from './media-resource'

export {
  MediaModel as resource,
} from './entities/sequelize'
