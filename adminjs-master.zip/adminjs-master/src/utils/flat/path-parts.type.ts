export type PathParts = Array<string>
