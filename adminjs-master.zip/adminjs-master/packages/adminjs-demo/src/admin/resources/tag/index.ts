export {
  options,
  features,
} from './tag-resource'
export { TagModel as resource } from './entities/sequelize'
