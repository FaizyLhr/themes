export { default as BaseResource } from './base-resource'
export * from './supported-databases.type'
