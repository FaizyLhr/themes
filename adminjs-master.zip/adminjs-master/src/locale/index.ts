export { default as defaultLocale } from './en'
export * from './config'
