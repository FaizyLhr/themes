#!/usr/bin/env node
// eslint-disable-next-line
require('./lib/cli').default
